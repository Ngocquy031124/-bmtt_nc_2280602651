from string import ascil_uppercase
ALPHABET = list(ascil_uppercase)